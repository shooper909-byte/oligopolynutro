import {NextRequest,NextResponse} from 'next/server';
export function middleware(req:NextRequest){
  if(process.env.NODE_ENV!=='production') return NextResponse.next();
  const expected=process.env.OID_INTERNAL_ACCESS_TOKEN;
  if(!expected) return new NextResponse('OID production access token is not configured.',{status:503});
  const path=req.nextUrl.pathname;
  if(path==='/login'||path.startsWith('/api/v1/session')) return NextResponse.next();
  const cookie=req.cookies.get('oid_access_token')?.value;
  const auth=req.headers.get('authorization')?.replace(/^Bearer\s+/i,'');
  if(cookie===expected||auth===expected) return NextResponse.next();
  if(path.startsWith('/api/')) return NextResponse.json({error:'UNAUTHORIZED'},{status:401});
  return NextResponse.redirect(new URL('/login',req.url));
}
export const config={matcher:['/((?!_next/static|_next/image|favicon.ico).*)']};
