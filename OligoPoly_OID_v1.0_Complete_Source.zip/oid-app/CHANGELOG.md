# Changelog

## 1.0.0 — 2026-08-07

Completed OID MVP source architecture through M4:

- M0 Foundation
- M1 Traceability
- M2 Control
- M3 Intelligence
- M4 Migration

Added canonical Prisma-compatible PostgreSQL initialization migration, production internal access gate, RBAC, document hashing/storage adapter, Command Center and drill-down screens, exception/action/CAPA/decision controls, organization records, search, Ask OID evidence responses, migration conflict controls, Docker packaging, production gate, and validation runbook.
