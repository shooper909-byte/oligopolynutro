# OID v1 Production Gate

Do not represent OID as production-validated until all items below are complete and recorded.

## Build and database

- [ ] `npm install` succeeds from an approved package registry.
- [ ] `npx prisma validate` passes.
- [ ] `npx prisma generate` passes.
- [ ] Canonical migration applies cleanly to a disposable PostgreSQL 17 database.
- [ ] Migration rollback/recovery procedure is tested.
- [ ] `npm run build` passes.
- [ ] Unit/integration/e2e suite passes.

## Critical controls

- [ ] Attempted allocation from QUARANTINE fails at service and database layers.
- [ ] Attempted allocation from HOLD/REJECTED/RECALLED fails.
- [ ] Attempted release without reviewed independent PASS fails.
- [ ] Attempted release with open RELEASE/ALL blocker fails.
- [ ] Failed or inconclusive test places the lot into the defined hold/investigation workflow.
- [ ] Negative inventory cannot be created under concurrent allocation attempts.
- [ ] Audit UPDATE/DELETE attempts fail.
- [ ] Document hash duplicate handling behaves as approved.

## Traceability exercise

Run one synthetic passing lot through:

Supplier -> PO -> Receipt -> Lot -> Sample -> Lab -> Test -> Review -> Release -> Inventory -> Allocation

Run one synthetic failing lot through:

Test failure -> HOLD -> Exception -> CAPA/investigation -> final disposition

Retain screenshots/logs as validation evidence.

## Security

- [ ] Replace all sample credentials and tokens.
- [ ] Use TLS at the reverse proxy/load balancer.
- [ ] Use a managed secret store.
- [ ] Confirm database is not publicly exposed.
- [ ] Confirm private document storage is not publicly exposed.
- [ ] Test backups and restore.
- [ ] Test access revocation.
- [ ] Review RBAC with system owner and quality owner.
- [ ] Replace the internal single-token gate with SSO before multi-user deployment.
- [ ] Perform vulnerability/dependency scanning.

## Governance

- [ ] Quality owner approves workflow/status vocabulary.
- [ ] Counsel reviews business/regulatory use where appropriate.
- [ ] Data-retention and correction policies are approved.
- [ ] Founder-reserved decisions are confirmed.
- [ ] AI retrieval scope and sensitive-data rules are approved.
