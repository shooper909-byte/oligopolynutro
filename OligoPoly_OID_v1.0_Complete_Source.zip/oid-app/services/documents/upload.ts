import { db } from "../../lib/database";
import { requirePermission, PERMISSIONS } from "../../lib/permissions";
import { nextOidCode } from "../../lib/oid-identifiers/counter";
import { LocalPrivateStorage } from "../../lib/storage";
import { sha256Buffer } from "./hash";

export async function uploadDocument(args: { filename: string; mimeType: string; bytes: Buffer; documentType: any; title: string; entityType?: string; entityId?: string; userId: string; permissions: Iterable<string> }) {
  requirePermission(args.permissions, PERMISSIONS.DOCUMENT_UPLOAD);
  if (args.bytes.length === 0) throw new Error("EMPTY_DOCUMENT");
  if (args.bytes.length > 25 * 1024 * 1024) throw new Error("DOCUMENT_TOO_LARGE");
  const hash = sha256Buffer(args.bytes);
  const duplicate = await db.document.findFirst({ where: { sha256Hash: hash, status: "ACTIVE" } });
  if (duplicate) throw new Error(`DUPLICATE_DOCUMENT:${duplicate.oidCode}`);
  const oidCode = await nextOidCode(db, "DOC");
  const safeName = args.filename.replace(/[^A-Za-z0-9._-]/g, "_");
  const key = `${new Date().getUTCFullYear()}/${oidCode}/${safeName}`;
  await new LocalPrivateStorage().put(key, args.bytes);
  return db.$transaction(async tx => {
    const doc = await tx.document.create({ data: { oidCode, documentType: args.documentType, title: args.title, originalFilename: args.filename, storageKey: key, mimeType: args.mimeType, fileSize: args.bytes.length, sha256Hash: hash, uploadedBy: args.userId } });
    if (args.entityType && args.entityId) await tx.documentLink.create({ data: { documentId: doc.id, entityType: args.entityType, entityId: args.entityId, createdBy: args.userId } });
    await tx.auditLog.create({ data: { oidCode: await nextOidCode(tx, "AUD"), eventType: "CREATE", userId: args.userId, entityType: "DOCUMENT", entityId: doc.id, newValues: { oidCode, hash, entityType: args.entityType, entityId: args.entityId } } });
    return doc;
  });
}
