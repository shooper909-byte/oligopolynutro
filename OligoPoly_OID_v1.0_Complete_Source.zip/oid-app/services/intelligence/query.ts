import { db } from "../../lib/database";
import { requirePermission, PERMISSIONS } from "../../lib/permissions";
import { explainLotStatus } from "./lot-answer";

export async function queryOid(args:{question:string;userId:string;permissions:Iterable<string>}){
  requirePermission(args.permissions,PERMISSIONS.INTELLIGENCE_QUERY);
  const q=args.question.trim();
  const code=q.match(/OID-LOT-\d{4}-\d{5}/i)?.[0]?.toUpperCase();
  if(code){
    const lot=await db.lot.findUnique({where:{oidCode:code},include:{testResults:true,exceptions:true}});
    if(!lot) return {answer:`${code} was not found.`,confidence:"LOW",evidence:[],conflictingEvidence:[],unknowns:["The requested lot identifier does not exist in OID."],requiredActions:["Verify the lot identifier."]};
    const response=explainLotStatus({oidCode:lot.oidCode,status:lot.status,releaseGateStatus:lot.releaseGateStatus,tests:lot.testResults.map(t=>({oidCode:t.oidCode,resultStatus:t.resultStatus,reviewStatus:t.reviewStatus})),exceptions:lot.exceptions.map(e=>({oidCode:e.oidCode,status:e.status,blocksProcess:e.blocksProcess,summary:e.title})),traceabilityComplete:Boolean(lot.purchaseOrderId&&lot.receiptId&&lot.receiptItemId)});
    await db.intelligenceQuery.create({data:{userId:args.userId,question:q,normalizedQuestion:q.toLowerCase(),answer:response.answer,confidence:response.confidence,evidence:response.evidence as any,conflictingEvidence:response.conflictingEvidence as any,unknowns:response.unknowns as any,requiredActions:response.requiredActions as any}});
    return response;
  }
  const results=await Promise.all([
    db.product.findMany({where:{OR:[{name:{contains:q,mode:'insensitive'}},{oidCode:{contains:q,mode:'insensitive'}}]},take:5}),
    db.supplier.findMany({where:{OR:[{legalName:{contains:q,mode:'insensitive'}},{oidCode:{contains:q,mode:'insensitive'}}]},take:5}),
    db.exception.findMany({where:{OR:[{title:{contains:q,mode:'insensitive'}},{oidCode:{contains:q,mode:'insensitive'}}]},take:5})
  ]);
  const evidence=[...results[0].map(x=>({oidCode:x.oidCode,entityType:'PRODUCT',summary:x.name})),...results[1].map(x=>({oidCode:x.oidCode,entityType:'SUPPLIER',summary:x.legalName})),...results[2].map(x=>({oidCode:x.oidCode,entityType:'EXCEPTION',summary:x.title}))];
  return {answer:evidence.length?`OID found ${evidence.length} records related to the query.`:"OID found no directly matching records.",confidence:evidence.length>1?"MODERATE":"LOW",evidence,conflictingEvidence:[],unknowns:evidence.length?[]:["No matching authoritative record was found."],requiredActions:[]};
}
