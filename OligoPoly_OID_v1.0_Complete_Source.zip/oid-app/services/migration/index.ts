import { createHash } from "node:crypto";
import { db } from "../../lib/database";
import { requirePermission, PERMISSIONS } from "../../lib/permissions";
import { classifyLegacyRow, type LegacyRow } from "../../lib/migration";
export async function stageImport(args:{name:string;sourceName:string;bytes:Buffer;userId:string;permissions:Iterable<string>}){requirePermission(args.permissions,PERMISSIONS.MIGRATION_RUN);const hash=createHash('sha256').update(args.bytes).digest('hex');return db.importBatch.create({data:{name:args.name,sourceName:args.sourceName,sourceSha256:hash,createdBy:args.userId}})}
export function dryRunRows(rows:LegacyRow[],requiredFields:string[]){const seen=new Set<string>();return rows.map(row=>{const key=row.legacyIdentifier??`${row.source}:${row.sheet}:${row.row}`;const duplicate=seen.has(key);seen.add(key);const status=classifyLegacyRow({row,requiredFields,duplicate,conflicts:[]});return{row,status}})}
