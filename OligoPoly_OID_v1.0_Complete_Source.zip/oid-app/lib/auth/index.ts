import { ROLE_PERMISSIONS } from "../permissions";
export type Actor={userId:string;email:string;roles:string[];permissions:Set<string>};
export function actorFromRoles(userId:string,email:string,roles:string[]):Actor{const permissions=new Set<string>();for(const role of roles)for(const permission of ROLE_PERMISSIONS[role]??[])permissions.add(permission);return{userId,email,roles,permissions}}
export function developmentActor():Actor{if(process.env.NODE_ENV==='production')throw new Error('DEVELOPMENT_ACTOR_DISABLED_IN_PRODUCTION');return actorFromRoles('00000000-0000-0000-0000-000000000001','founder@local.oid',['FOUNDER'])}
export function internalMvpActor():Actor{return actorFromRoles(process.env.OID_INTERNAL_USER_ID??'00000000-0000-0000-0000-000000000001',process.env.OID_INTERNAL_USER_EMAIL??'founder@oid.internal',['FOUNDER'])}
export function actorForServerRequest():Actor{return process.env.NODE_ENV==='production'?internalMvpActor():developmentActor()}
