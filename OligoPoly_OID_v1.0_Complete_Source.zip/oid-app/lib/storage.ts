import { mkdir, writeFile, readFile } from "node:fs/promises";
import { dirname, join } from "node:path";

export interface ObjectStorage { put(key: string, bytes: Buffer): Promise<void>; get(key: string): Promise<Buffer>; }
export class LocalPrivateStorage implements ObjectStorage {
  constructor(private root = process.env.OID_STORAGE_ROOT ?? "/var/lib/oid/private") {}
  async put(key: string, bytes: Buffer) { const path = join(this.root, key); await mkdir(dirname(path), { recursive: true }); await writeFile(path, bytes, { mode: 0o600 }); }
  async get(key: string) { return readFile(join(this.root, key)); }
}
