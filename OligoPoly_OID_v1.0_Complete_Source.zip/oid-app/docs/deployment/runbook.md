# Deployment Runbook

1. Provision PostgreSQL 17 in a private network.
2. Provision encrypted private object/file storage for `OID_STORAGE_ROOT` or replace `LocalPrivateStorage` with the approved managed-object-storage adapter.
3. Generate a long random `OID_INTERNAL_ACCESS_TOKEN`; never commit it.
4. Set `DATABASE_URL`, storage path, internal user email/user ID, and production token through the deployment secret manager.
5. Build the image.
6. Run `prisma migrate deploy` against a disposable environment first.
7. Run the full production gate.
8. Back up the database and storage configuration before first live import.
9. Import legacy records only as staged/unreviewed evidence; resolve conflicts before promotion.
10. Record the go-live decision in OID's Decision register once the system itself is operational.

For multi-user use, implement managed SSO before rollout and remove the shared internal token workflow.
